<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: loginnnn.html"); // Redirect to login if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>notification</title>
    <style>
      *{
        margin: 0px;
        padding: 0px;
      }
/* decision buttons */
      .BOX{
        border-radius: 27px;
      padding: 30px 50px 0px 30px;
      font-family: calibri;
      background-color: aliceblue;
      text-align: center;
      width: 90px; /* Adjust the width as needed */
      margin: 0 auto; /* Centers the div horizontally */
      padding: 174px 33px 85px 33px; /* Vertical padding remains */
      
      }
/* would you like to---heading */
      h{
        font-size: 28px;
        font-family: calibri;
        font-weight: normal;
        margin-top: 20px;
        letter-spacing: -1px;
      }
/* decision buttons */
      .decision{
        color: white;
        background-color: #005288;
        font-family: calibri;
        font-weight: bold;
        font-size: 19px;
        letter-spacing: 0.6px;
        margin-top: 50px;
        border: none;
        border-radius: 5px;
      }
      .decision:hover{
        cursor: pointer;
        color: lightblue;
      }
      .username {
        font-size: 28px; /* Adjust font size as needed */
        color: #000000; /* Adjust text color */
        /* font-weight: bold; Adjust font weight */
    }
    </style>
</head>
<body>
<!-- background graph image -->
    <img src="graph.jpeg" style= "height: 100vh; width: 100vw; position: absolute; z-index: -1;">
<!-- side box -->
    <div class= "BOX" style="height: 64.9vh; width: 34vw;">
<!-- notificatiion bell -->
      <img src="bells.png" style="height: 50px; width: 50px; margin-bottom: 5px;"><br>
      <span id="username" class="username"></span>
<br>
      <h>You have recceived a report</h><br>
<!-- decision buttons -->
        <a href="portal2_page1_report.html" id="generateReportBtn"><button class="decision" type="decision" style="height: 35px; width: 220px;"> Accept </button></a><br>
        <a href="logout.php"><button class="decision" type="decision" style="margin-top: 22px; height: 35px; width: 220px;"> Reject $ Log Out</button></a><br>

    </div>


    <script>
      document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function (event) {
          event.preventDefault(); 
          const href = this.getAttribute('href');
          window.location.href = href;
        });
      });
    </script>
    
  
    <script>

      
     // document.getElementById('generateReportBtn').addEventListener('click', function () {
       // fetch('generate_report.php')
         // .then(response => {
           // if (!response.ok) {
            //  throw new Error('Failed to generate report');
           // }
       //     return response.text();
     //     })
     //     .then(data => {
            // Redirect to reportportal1.html with the generated report
       //     window.location.href = 'reportportal1.html?report=static/reports/monthly_report.pdf';
     //     })
       //   .catch(error => {
         //   alert('Error: ' + error.message);
    ///      });
    //  });
  
    
     // document.getElementById('generateReportBtn').addEventListener('click', function () {
       // fetch('generate_report.php')
        //  .then(response => response.text())
      //    .then(data => {
      //      alert(data);  // Show the result of the report generation
        //    // Redirect to reportportal1.php after the report is generated
    //        window.location.href = 'reportportal1.php';
     //     })
    //      .catch(error => {
     //       alert('Error: ' + error.message);
   //       });
  //    });
   

//   document.getElementById('generateReportBtn').addEventListener('click', function () {
//     // Path to the report
//     const reportPath = 'static/reports/monthly_report.pdf';

//     // Create a new request to check if the report exists
//     fetch(reportPath, { method: 'HEAD' })
//         .then(response => {
//             if (response.ok) {
//                 // If the response is OK, redirect to the report viewing page
//                 window.location.href = 'portal2_page1_report.html';
//             } else {
//                 // If the response is not OK, alert the user that the report does not exist
//                 alert('Report not found.');
//             }
//         })
//         .catch(error => {
//             // Handle any errors that occur during the fetch request
//             alert('Error: ' + error.message);
//         });
// });

fetch('session_check.php')
            .then(response => response.text())
            .then(data => {
                if (data === "NA") {
                    window.location.href = 'loginnnn.html'; // Redirect to login page if NA
                } else {
                    document.getElementById('username').innerText = data;
                }
            })

//     </script>
  
  <script>
    document.getElementById('generateReportBtn').addEventListener('click', function () {
      const reportPath = 'static/reports/monthly_report.pdf';
  
      // Display loading message or spinner
      const loadingMessage = document.createElement('div');
      loadingMessage.innerText = 'Checking report availability...';
      document.body.appendChild(loadingMessage);
  
      fetch(reportPath, { method: 'HEAD' })
          .then(response => {
              // Remove loading message
              document.body.removeChild(loadingMessage);
              if (response.ok) {
                  window.location.href = 'portal2_page1_report.html';
              } else {
                  alert('Report not found.');
              }
          })
          .catch(error => {
              document.body.removeChild(loadingMessage);
              alert('Error: ' + error.message);
          });
  });
  </script>
  
    
</body>
</html>