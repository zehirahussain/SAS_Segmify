//<?php
//$servername = "localhost";
//$username = "root";
//$password = "";
//$dbname = "loginandanalysis";

//$conn = mysqli_connect($servername, $username, $password, $dbname);

//if (!$conn) {
//    die("Connection failed: " . mysqli_connect_error());
//}


//// sql to delete a record
//$sql = "DELETE FROM users WHERE id ='$id'";

//if ($conn->query($sql) === TRUE) {
//  echo "Record deleted successfully";
//} else {
//  echo "Error deleting record: " . $conn->error;
//}

//$conn->close();
//?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loginandanalysis";

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the delete operation is requested
if (isset($id)) {
    // sql to delete a record
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $stmt->error;
    }
    $stmt->close();
}
?>
